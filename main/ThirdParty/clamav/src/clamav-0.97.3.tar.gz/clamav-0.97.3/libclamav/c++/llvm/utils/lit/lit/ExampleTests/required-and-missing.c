// This test shouldn't be run, the required feature is missing.
//
// RUN: false
// REQUIRES: some-missing-feature-name
